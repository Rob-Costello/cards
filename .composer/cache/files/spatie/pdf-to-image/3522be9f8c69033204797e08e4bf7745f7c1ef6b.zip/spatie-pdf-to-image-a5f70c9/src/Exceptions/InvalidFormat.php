<?php

namespace Spatie\PdfToImage\Exceptions;

use Exception;

class InvalidFormat extends Exception
{
}
