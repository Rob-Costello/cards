<?php

namespace Spatie\PdfToImage\Exceptions;

use Exception;

class InvalidLayerMethod extends Exception
{
}
